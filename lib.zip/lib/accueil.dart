import 'package:just_audio/just_audio.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:intl/intl.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:rosaire/notif_help.dart';
import 'param.dart';

class Accueil extends StatefulWidget {
  final String login;

  const Accueil(this.login);

  @override
  State<Accueil> createState() => _AccueilState();
}

class _AccueilState extends State<Accueil> {
  String prenom = "";
  String email = "";
  String usernum = "";
  String numequipe = "";
  int nummedit = 0;

  String entete = " ";
  String titre = "";
  String titreEvangile = "";
  String texteEvangile = "";
  String texteMeditation = "";
  String texteIntentions = "";
  String texteFruit = "";
  String texteClausules = "";
  String imgUrl = "";
  String audioUrl = "";
  String videoUrl = "";

  List<Map> usersConnected = [];

  final playeraudio = AudioPlayer();

  @override
  void initState() {
    super.initState();
    getUserPhp(widget.login);
    NotificationService().init();
  }

  // on récupère les données de l'utilisateur depuis la shared préference Login
  getUserPhp(String loginId) async {
    print(
        "medit.dart : uri = http://app.equipes-rosaire.org/user2.php?Login=$loginId");
    var uri =
        Uri.parse("http://app.equipes-rosaire.org/user2.php?Login=$loginId");
    var response = await http.post(uri);
    var jsonMedit = jsonDecode(response.body);
    print('getUserPhp() ££££££££££££££ Response body: ${response.body}');
    setState(() {
      prenom = jsonMedit['Prenom'];
      email = jsonMedit['Email'];
      numequipe = jsonMedit['Numequipe'];
      usernum = jsonMedit['Usernum'];
      nummedit = int.parse(jsonMedit['Nummedit']) - 1;
    });
    getMeditPhp();
  getConnectPhp();
  }

  // on récupère la liste des méditations
  getMeditPhp() async {
    var uri = Uri.parse("http://app.equipes-rosaire.org/json2.php");
    var response = await http.post(uri);

    var jsonMedit = jsonDecode(response.body);
    //print(jsonMedit);
    //print("nummedit : $nummedit");

    setState(() {
      entete = jsonMedit[nummedit]['Code'];
      titre = jsonMedit[nummedit]['Titre'];
      titreEvangile = jsonMedit[nummedit]['TitreEvangile'];
      texteEvangile = jsonMedit[nummedit]['TexteEvangile'];
      texteMeditation = jsonMedit[nummedit]['TexteMeditation'];
      texteIntentions = jsonMedit[nummedit]['TexteIntentions'];
      texteFruit = jsonMedit[nummedit]['TexteFruit'];
      texteClausules = jsonMedit[nummedit]['TexteClausules'];

      imgUrl =
          "http://app.equipes-rosaire.org/Img/" + jsonMedit[nummedit]['Img'];

      audioUrl = jsonMedit[nummedit]['Audio'];

      videoUrl = jsonMedit[nummedit]['Video'];
    });

  }
// on récupère la liste des connexions
  getConnectPhp() async {
    var uri = Uri.parse("http://app.equipes-rosaire.org/journal2.php");
    var response = await http.post(uri);

    var jsonConnexions = jsonDecode(response.body);
    print(jsonConnexions);

    jsonConnexions.forEach((data) {
      print(data);
      usersConnected.add(data);
    });

    ;

    setState(() {
      usersConnected = usersConnected;
    });
  }




  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 80,
        automaticallyImplyLeading: false,
        backgroundColor: Colors.white,
        title: Center(
          child: Container(
            height: 80,
            child: Image.asset(
              'assets/EdR_splash.png',
              fit: BoxFit.fitWidth,
            ),
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(30.0),
        child: ListView(
          children: [
            Text("Bonjour $prenom !",
                style: TextStyle(
                  fontStyle: FontStyle.italic,
                  fontWeight: FontWeight.bold,
                  fontSize: 20,
                  color: colorTitle[entete[0]],
                )),
            RichText(
              text: TextSpan(
                text:
                    "aujourd'hui, ${jourFR[dayOfWeek]} $day ${moisFR[mois]}  $year, vous méditez un ",
                style: TextStyle(fontSize: 15, color: colorTitle[entete[0]]),
                children:  <TextSpan>[
                  TextSpan(
                      text: "mystère ${famille[entete[0]]}",
                      style: TextStyle(fontWeight: FontWeight.bold))
                ],
              ),
            ),

            SizedBox(height: 20.0),

            Container(
              decoration: BoxDecoration(
                  color: colorTitle[entete[0]],
                  borderRadius: BorderRadius.all(Radius.circular(8.0))),
              child: Column(children: [
                Container(
                    width: double.infinity,
                    //color:colorTitle[entete[0]],
                    child: Text(titre,
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 22,
                            color: Colors.white),
                        textAlign: TextAlign.center)),
                Container(
                    width: double.infinity,
                    //color:colorTitle[entete[0]],
                    child: Text(titreEvangile,
                        style: TextStyle(fontSize: 14, color: Colors.white),
                        textAlign: TextAlign.center)),
              ]),
            ),
            SizedBox(height: 20.0),
            Container(
              child: Text("toto",
                  style: GoogleFonts.lato(
                      fontStyle: FontStyle.italic, fontSize: 14)),
            ),
            SizedBox(height: 20.0),
            TextButton(
                onPressed: () {
                  NotificationService().showNotif(15);
                },
                child: Text("recevoir notification")),


                            ListView.builder(
                physics: NeverScrollableScrollPhysics(),
                shrinkWrap: true,
                itemCount: usersConnected.length,
                itemBuilder: (BuildContext context, int index) {
                  return Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(usersConnected[index]["Meditation"]),
                        Text(" : "),
                        Text(usersConnected[index]["Prenom"]),
                        Text(" "),
                        Text(usersConnected[index]["DateConnexion"]),
                      ]);
                }),
          ],

          
        ),
      ),
    bottomNavigationBar: BottomNavigationBar(
    items: const <BottomNavigationBarItem>[
      BottomNavigationBarItem(
        icon: Icon(Icons.call),
        label: 'Lien vers le site',
      ),
      BottomNavigationBarItem(
        icon: Icon(Icons.camera),
        label: 'Mystère',
      ),
      BottomNavigationBarItem(
        icon: Icon(Icons.flash_off),
        label: 'Laisser un message',
      ),
    ],
  ),
);
    
  }
}
